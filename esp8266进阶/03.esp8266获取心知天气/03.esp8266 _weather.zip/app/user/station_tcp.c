#include "ets_sys.h"
#include "osapi.h"
#include "user_interface.h"

#include "espconn.h"
#include "user_json.h"
#include "station_tcp.h"

char station_ssid[32] = "iPhone1";
char station_password[64] =  "87654321";


#define dns_ip "api.seniverse.com"
#define tcp_send_data  "GET /v3/weather/now.json?key=SW3LLISDooWbJTdiF&location=yantai&language=zh-Hans&unit=c HTTP/1.1\r\n"\
                       "Host:api.seniverse.com \r\n"                 \
                       "Cnnection:close \r\n\r\n"
/**************************esp8266_Station ģʽ��ʼ������*****************************/
//#define station_config_ssid     "iPhone1"
//#define station_config_password "12345678"

void ICACHE_FLASH_ATTR esp8266_station_config(void)
{
	struct	station_config station_config;


	wifi_set_opmode(0x01);         //����Ϊstation ģʽ
	os_memcpy(&station_config.ssid,station_ssid,32);
	os_memcpy(&station_config.password,station_password,64);
	station_config.bssid_set = 0;
	wifi_station_set_config	(&station_config);
}

struct	espconn tcp_config;
esp_tcp tcp_config_proto;
ip_addr_t	ip_addr;
u8 i=0;
/**************************esp8266_TCP �������ݻص�����*************************/
void ICACHE_FLASH_ATTR esp8266_recv_callback(void *arg, char *pdata, unsigned short len)
{
	i++;
	struct	espconn	*pesp_conn	=	arg;
	os_printf("\r\n=============Receive Data=============\r\n");
	tcp_recv_data = pdata;
	os_printf("%s ",tcp_recv_data);
	if((i%2)==0)
	{
		Parse_JSON_Tree_JX(tcp_recv_data);
	}
}

/**************************esp8266_TCP �������ݻص�����************************/
void ICACHE_FLASH_ATTR esp8266_sent_callback(void *arg)
{
	os_printf("\r\n=============Send Data OK=============\r\n ");
}
/**************************esp8266_TCP ���ӳɹ��ص�����***********************/
void ICACHE_FLASH_ATTR esp8266_tcp_connect_callback(void	*arg)
{
	struct	espconn	*send_arg	=	(struct	espconn	*)arg;
	espconn_regist_sentcb(arg,esp8266_sent_callback); //ע��ɹ�����?�����ݵĻص�����
	espconn_regist_recvcb(arg,esp8266_recv_callback); //ע��ɹ�����?�����ݵĻص�����
	os_printf("\r\n=============TCP Connect=============\r\n");
	espconn_send(send_arg, tcp_send_data,os_strlen( tcp_send_data));
}
/**************************esp8266_TCP �Ͽ��ص�����*************************/
void ICACHE_FLASH_ATTR  esp8266_tcp_disconnect_callback(void	*arg)
{
	os_printf("\r\n=============TCP Disconnect=============\r\n");
}
/**************************esp8266_dns �ص�����******************************/
void ICACHE_FLASH_ATTR esp8266_dns_callback(const	char	*name,	ip_addr_t	*ipaddr,	void	*arg)
{
	struct	espconn	*pespconn	=	(struct	espconn	*)arg;

	if	(ipaddr	!=	NULL)
	{
	os_printf("user_esp_platform_dns_found	%d.%d.%d.%d\n",
			*((uint8	*)&ipaddr->addr),	*((uint8	*)&ipaddr->addr	+	1),
			*((uint8	*)&ipaddr->addr	+	2),	*((uint8	*)&ipaddr->addr	+	3));
	os_memcpy(pespconn->proto.tcp->remote_ip,&ipaddr->addr,4);
	espconn_connect(pespconn);
	}
}
/**************************esp8266_TCP Э������*****************************/
void ICACHE_FLASH_ATTR esp8266_tcp_config(void)
{
	tcp_config.type = ESPCONN_TCP  ;            //tcpģʽͨ��
	tcp_config.proto.tcp = &tcp_config_proto;
	tcp_config.proto.tcp->local_port = 8266;    //�����˿�
	//����Զ����Ϣ 172.20.10.3
	tcp_config.proto.tcp->remote_port = 80;
	//ע��ص�����
	espconn_regist_connectcb(&tcp_config,esp8266_tcp_connect_callback);
	espconn_regist_disconcb (&tcp_config,esp8266_tcp_disconnect_callback);
	//DNS
	espconn_gethostbyname(&tcp_config,dns_ip,&ip_addr,esp8266_dns_callback);
}

