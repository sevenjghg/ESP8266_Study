#include "ets_sys.h"
#include "osapi.h"
#include "user_interface.h"

#include "espconn.h"





char A_JSON_Tree[256] = {0};    // ���JSON��


/******************************************************************************
 * FunctionName : Parse_JSON_Tree_JX
 * Description  : ����json��
 * Parameters   : none
 * Returns      : none
*******************************************************************************/
void Parse_JSON_Tree_JX(char *pdata)
{
        os_printf("\r\n---------------------------------------\r\n");

        char A_JSONTree_Value[64] = {0};    // JSON���ݻ�������

        char * T_Pointer_Head = NULL;        // ��ʱָ��
        char * T_Pointer_end = NULL;        // ��ʱָ��

        u8 T_Value_Len = 0;                 // ��"ֵ"���ĳ���

        //������������������������������������������������������������������������������������
        T_Pointer_Head = strstr(pdata, "\"location\"");
        os_printf("location:\n");

        T_Pointer_Head = strstr(T_Pointer_Head, "\"id\"");
        T_Pointer_Head = strstr(T_Pointer_Head, ":");
        T_Pointer_Head = strstr(T_Pointer_Head, "\"") + 1;
        T_Pointer_end = strstr(T_Pointer_Head, "\"");
        T_Value_Len = T_Pointer_end - T_Pointer_Head;
        memcpy(A_JSONTree_Value, T_Pointer_Head, T_Value_Len);
        A_JSONTree_Value[T_Value_Len] = '\0';
        os_printf("\t temp:%s\n",A_JSONTree_Value);

        T_Pointer_Head = strstr(T_Pointer_Head, "\"name\"");
        T_Pointer_Head = strstr(T_Pointer_Head, ":");
        T_Pointer_Head = strstr(T_Pointer_Head, "\"") + 1;
        T_Pointer_end = strstr(T_Pointer_Head, "\"");
        T_Value_Len = T_Pointer_end - T_Pointer_Head;
        memcpy(A_JSONTree_Value, T_Pointer_Head, T_Value_Len);
        A_JSONTree_Value[T_Value_Len] = '\0';
        os_printf("\t name:%s\n",A_JSONTree_Value);

        T_Pointer_Head = strstr(T_Pointer_Head, "\"country\"");
        T_Pointer_Head = strstr(T_Pointer_Head, ":");
        T_Pointer_Head = strstr(T_Pointer_Head, "\"") + 1;
        T_Pointer_end = strstr(T_Pointer_Head, "\"");
        T_Value_Len = T_Pointer_end - T_Pointer_Head;
        memcpy(A_JSONTree_Value, T_Pointer_Head, T_Value_Len);
        A_JSONTree_Value[T_Value_Len] = '\0';
        os_printf("\t country:%s\n",A_JSONTree_Value);

        T_Pointer_Head = strstr(T_Pointer_Head, "\"path\"");
        T_Pointer_Head = strstr(T_Pointer_Head, ":");
        T_Pointer_Head = strstr(T_Pointer_Head, "\"") + 1;
        T_Pointer_end = strstr(T_Pointer_Head, "\"");
        T_Value_Len = T_Pointer_end - T_Pointer_Head;
        memcpy(A_JSONTree_Value, T_Pointer_Head, T_Value_Len);
        A_JSONTree_Value[T_Value_Len] = '\0';
        os_printf("\t path:%s\n",A_JSONTree_Value);

        T_Pointer_Head = strstr(T_Pointer_Head, "\"timezone\"");
        T_Pointer_Head = strstr(T_Pointer_Head, ":");
        T_Pointer_Head = strstr(T_Pointer_Head, "\"") + 1;
        T_Pointer_end = strstr(T_Pointer_Head, "\"");
        T_Value_Len = T_Pointer_end - T_Pointer_Head;
        memcpy(A_JSONTree_Value, T_Pointer_Head, T_Value_Len);
        A_JSONTree_Value[T_Value_Len] = '\0';
        os_printf("\t timezone:%s\n",A_JSONTree_Value);

        T_Pointer_Head = strstr(T_Pointer_Head, "\"timezone_offset\"");
        T_Pointer_Head = strstr(T_Pointer_Head, ":");
        T_Pointer_Head = strstr(T_Pointer_Head, "\"") + 1;
        T_Pointer_end = strstr(T_Pointer_Head, "\"");
        T_Value_Len = T_Pointer_end - T_Pointer_Head;
        memcpy(A_JSONTree_Value, T_Pointer_Head, T_Value_Len);
        A_JSONTree_Value[T_Value_Len] = '\0';
        os_printf("\t timezone_offset:%s\n",A_JSONTree_Value);

        T_Pointer_Head = strstr(T_Pointer_Head, "\"now\"");
        os_printf("now:\n");

        T_Pointer_Head = strstr(T_Pointer_Head, "\"text\"");
        T_Pointer_Head = strstr(T_Pointer_Head, ":");
        T_Pointer_Head = strstr(T_Pointer_Head, "\"") + 1;
        T_Pointer_end = strstr(T_Pointer_Head, "\"");
        T_Value_Len = T_Pointer_end - T_Pointer_Head;
        memcpy(A_JSONTree_Value, T_Pointer_Head, T_Value_Len);
        A_JSONTree_Value[T_Value_Len] = '\0';
        os_printf("\t text:%s\n",A_JSONTree_Value);

        T_Pointer_Head = strstr(T_Pointer_Head, "\"code\"");
        T_Pointer_Head = strstr(T_Pointer_Head, ":");
        T_Pointer_Head = strstr(T_Pointer_Head, "\"") + 1;
        T_Pointer_end = strstr(T_Pointer_Head, "\"");
        T_Value_Len = T_Pointer_end - T_Pointer_Head;
        memcpy(A_JSONTree_Value, T_Pointer_Head, T_Value_Len);
        A_JSONTree_Value[T_Value_Len] = '\0';
        os_printf("\t code:%s\n",A_JSONTree_Value);

        T_Pointer_Head = strstr(T_Pointer_Head, "\"temperature\"");
        T_Pointer_Head = strstr(T_Pointer_Head, ":");
        T_Pointer_Head = strstr(T_Pointer_Head, "\"") + 1;
        T_Pointer_end = strstr(T_Pointer_Head, "\"");
        T_Value_Len = T_Pointer_end - T_Pointer_Head;
        memcpy(A_JSONTree_Value, T_Pointer_Head, T_Value_Len);
        A_JSONTree_Value[T_Value_Len] = '\0';
        os_printf("\t temperature:%s\n",A_JSONTree_Value);

        T_Pointer_Head = strstr(T_Pointer_Head, "\"last_update\"");
        T_Pointer_Head = strstr(T_Pointer_Head, ":");
        T_Pointer_Head = strstr(T_Pointer_Head, "\"") + 1;
        T_Pointer_end = strstr(T_Pointer_Head, "\"");
        T_Value_Len = T_Pointer_end - T_Pointer_Head;
        memcpy(A_JSONTree_Value, T_Pointer_Head, T_Value_Len);
        A_JSONTree_Value[T_Value_Len] = '\0';
        os_printf("last_update:%s\n",A_JSONTree_Value);

        T_Pointer_Head = strstr(T_Pointer_Head, "}");
        os_printf("\r\n---------------------------------------\r\n");

       return ;

}


