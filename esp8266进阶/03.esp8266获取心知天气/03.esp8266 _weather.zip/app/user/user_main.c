/*
 * ESPRESSIF MIT License
 *
 * Copyright (c) 2016 <ESPRESSIF SYSTEMS (SHANGHAI) PTE LTD>
 *
 * Permission is hereby granted for use on ESPRESSIF SYSTEMS ESP8266 only, in which case,
 * it is free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the Software is furnished
 * to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#include "ets_sys.h"
#include "osapi.h"
#include "user_interface.h"

#include "espconn.h"
#include "station_tcp.h"
#include "user_json.h"
//宏定義

/******************************************************************************
 * 系统函数 无需操作
*******************************************************************************/
uint32 ICACHE_FLASH_ATTR
user_rf_cal_sector_set(void)
{
    enum flash_size_map size_map = system_get_flash_size_map();
    uint32 rf_cal_sec = 0;

    switch (size_map) {
        case FLASH_SIZE_4M_MAP_256_256:
            break;

        case FLASH_SIZE_8M_MAP_512_512:
            break;

        case FLASH_SIZE_16M_MAP_512_512:
            break;
        case FLASH_SIZE_16M_MAP_1024_1024:
            break;

        case FLASH_SIZE_32M_MAP_512_512:
            break;
        case FLASH_SIZE_32M_MAP_1024_1024:
            break;

        case FLASH_SIZE_64M_MAP_1024_1024:
            break;
        case FLASH_SIZE_128M_MAP_1024_1024:
            break;
        default:
            break;
    }

    return rf_cal_sec;
}
void ICACHE_FLASH_ATTR user_rf_pre_init(void)
{
}

/*****************************软件定时器中断函数***************************************/
os_timer_t	esp8266_os_timer_config;
void os_timer_interrupt(void)
{
	switch(wifi_station_get_connect_status ())
	{
	case 0: os_printf("\r\n==================STATION_IDLE==================\r\n");
		break;
	case 1: os_printf("\r\n===============STATION_CONNECTING================\r\n");
		break;
	case 2: os_printf("\r\n==============STATION_WRONG_PASSWORD==============\r\n");
		break;
	case 3: os_printf("\r\n===============STATION_NO_AP_FOUND================\r\n");
		break;
	case 4: os_printf("\r\n===============STATION_CONNECT_FAIL===============\r\n");
		break;
	case 5: os_printf("\r\n==================STATION_GOT_IP==================\r\n");
			os_timer_disarm	(&esp8266_os_timer_config);
			esp8266_tcp_config();

		break;

	}
}
/*****************************软件定时器初始化***************************************/
 void os_timer_config(uint32_t	milliseconds,bool	repeat_flag)
 {

	 os_timer_disarm	(&esp8266_os_timer_config);
	 os_timer_setfn(&esp8266_os_timer_config,(os_timer_func_t *)os_timer_interrupt,NULL );
	 os_timer_arm	(&esp8266_os_timer_config,milliseconds,repeat_flag );
 }

/******************************************************************************
 * FunctionName : user_init
 * Description  : entry of user application, init user function here
 * Parameters   : none
 * Returns      : none
*******************************************************************************/
void ICACHE_FLASH_ATTR user_init(void)
{
/*******************************************************************************
 * 函數PIN_FUNC_SELECT(PIN_NAME,FUNC)
 * PIN_NAME   管腳名字          PERIPHS_IO_MUX_ 加管腳名
 * FUNC       管腳功能          功能序號 - 1 （功能序號由ESP826管腳清單查找）
 * 函數GPIO_OUTPUT_SET(gpio_no,	bit_value)
 * gpio_no    IO口序號          GPIO_ID_PIN(IO口序號)
 * bit_value  1                      輸出高電平
 *            0                      輸出低電平
********************************************************************************/
	os_printf("\r\n===================================================\r\n");
	os_printf("\r\n esp8266 project \r\n");
	os_printf("\r\n IDE:AiThinker v1.5.2 \r\n");
	os_printf("\r\n SDK:nonos_sdk_v2.2 \r\n");
	os_printf("\r\n===================================================\r\n");
/********************************************************************************/
	system_soft_wdt_feed ();
	os_timer_config(1000,1);
	esp8266_station_config();


}

