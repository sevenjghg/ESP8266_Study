/*
 * ESPRESSIF MIT License
 *
 * Copyright (c) 2016 <ESPRESSIF SYSTEMS (SHANGHAI) PTE LTD>
 *
 * Permission is hereby granted for use on ESPRESSIF SYSTEMS ESP8266 only, in which case,
 * it is free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the Software is furnished
 * to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#include "ets_sys.h"
#include "osapi.h"
#include "user_interface.h"

#include "espconn.h"
#include "driver/uart.h"

//宏定義
//构造json树的结构
#define        JSON_Tree_Format    " { \n "                                \
                                    " \"Shanghai\": \n "                \
                                    " { \n "                            \
                                        " \"temp\": \"%s\", \n "        \
                                        " \"humid\": \"%s\" \n "        \
                                    " }, \n "                            \
                                                                        \
                                    " \"Shenzhen\": \n "                \
                                    " { \n "                            \
                                        " \"temp\": \"%s\", \n "        \
                                        " \"humid\": %s \n "            \
                                    " }, \n "                            \
                                                                        \
                                    " \"result\": \"%s\" \n "            \
                                " } \n "

char A_JSON_Tree[256] = {0};    // 存放JSON树
//結構體


/******************************************************************************
 * 系统函数 无需操作
*******************************************************************************/
uint32 ICACHE_FLASH_ATTR
user_rf_cal_sector_set(void)
{
    enum flash_size_map size_map = system_get_flash_size_map();
    uint32 rf_cal_sec = 0;

    switch (size_map) {
        case FLASH_SIZE_4M_MAP_256_256:
            break;

        case FLASH_SIZE_8M_MAP_512_512:
            break;

        case FLASH_SIZE_16M_MAP_512_512:
            break;
        case FLASH_SIZE_16M_MAP_1024_1024:
            break;

        case FLASH_SIZE_32M_MAP_512_512:
            break;
        case FLASH_SIZE_32M_MAP_1024_1024:
            break;

        case FLASH_SIZE_64M_MAP_1024_1024:
            break;
        case FLASH_SIZE_128M_MAP_1024_1024:
            break;
        default:
            break;
    }

    return rf_cal_sec;
}
void ICACHE_FLASH_ATTR user_rf_pre_init(void)
{
}

/******************************************************************************
 * FunctionName : Setup_JSON_Tree_JX
 * Description  : 创建json树
 * Parameters   : none
 * Returns      : none
*******************************************************************************/
void Setup_JSON_Tree_JX(void)
{

    // 赋值JSON树【赋值JSON_Tree_Format字符串中的格式字符】
    //--------------------------------------------------------------------------------------------
   os_sprintf(A_JSON_Tree, JSON_Tree_Format, "30C","30%RH","35C","50%RH","Shenzhen is too hot!");

    os_printf("\r\n-----------------------------------\r\n");

    os_printf("%s",A_JSON_Tree);    // 串口打印JSON树

    os_printf("\r\n--------------------------------------\r\n");
}
/******************************************************************************
 * FunctionName : Parse_JSON_Tree_JX
 * Description  : 解析json树
 * Parameters   : none
 * Returns      : none
*******************************************************************************/
void Parse_JSON_Tree_JX(void)
{
        os_printf("\r\n---------------------------------------\r\n");

        char A_JSONTree_Value[64] = {0};    // JSON数据缓存数组

        char * T_Pointer_Head = NULL;        // 临时指针
        char * T_Pointer_end = NULL;        // 临时指针

        u8 T_Value_Len = 0;                 // 【"值"】的长度


        // 【"Shanghai"】
        //………………………………………………………………………………………………………………
        T_Pointer_Head = strstr(A_JSON_Tree, "\"Shanghai\"");        // 【"Shanghai"】
        os_printf("Shanghai:\n");

    //    T_Pointer_Head = strstr(T_Pointer_Head, ":");                // 【:】
    //    T_Pointer_Head = strstr(T_Pointer_Head, "{");                // 【{】
        T_Pointer_Head = strstr(T_Pointer_Head, "\"temp\"");         // 【"temp"】
        T_Pointer_Head = strstr(T_Pointer_Head, ":");                // 【:】
        T_Pointer_Head = strstr(T_Pointer_Head, "\"") + 1;            // 【值的首指针】
        T_Pointer_end = strstr(T_Pointer_Head, "\"");                // 【"值"尾的"】
        T_Value_Len = T_Pointer_end - T_Pointer_Head;                    // 计算【值】的长度
        memcpy(A_JSONTree_Value, T_Pointer_Head, T_Value_Len);        // 获取【值】
        A_JSONTree_Value[T_Value_Len] = '\0';                            // 【值后添'\0'】
        os_printf("\t temp:%s\n",A_JSONTree_Value);


    //    T_Pointer_Head = strstr(T_Pointer_Head, ",");                // 【,】
    //    T_Pointer_Head = strstr(T_Pointer_Head, "\"");                // 【\"】
        T_Pointer_Head = strstr(T_Pointer_Head, "\"humid\"");        // 【"humid"】
        T_Pointer_Head = strstr(T_Pointer_Head, ":");                // 【:】
        T_Pointer_Head = strstr(T_Pointer_Head, "\"") + 1;            // 【值的首指针】
        T_Pointer_end = strstr(T_Pointer_Head, "\"");                // 【"值"尾的"】
        T_Value_Len = T_Pointer_end - T_Pointer_Head;                    // 计算【值】的长度
        memcpy(A_JSONTree_Value, T_Pointer_Head, T_Value_Len);        // 获取【值】
        A_JSONTree_Value[T_Value_Len] = '\0';                            // 【值后添'\0'】
        os_printf("\t humid:%s\n",A_JSONTree_Value);

        //    T_Pointer_Head = strstr(T_Pointer_Head, "}");            // 【}】
        //    T_Pointer_Head = strstr(T_Pointer_Head, ",");            // 【,】
        //………………………………………………………………………………………………………………


        // 【"Shenzhen"】
        //………………………………………………………………………………………………………………
        T_Pointer_Head = strstr(T_Pointer_Head, "\"Shenzhen\"");     // 【"Shenzhen"】
        os_printf("Shenzhen:\n");

    //    T_Pointer_Head = strstr(T_Pointer_Head, ":");                // 【:】
    //    T_Pointer_Head = strstr(T_Pointer_Head, "{");                // 【{】
        T_Pointer_Head = strstr(T_Pointer_Head, "\"temp\"");         // 【"temp"】
        T_Pointer_Head = strstr(T_Pointer_Head, ":");                // 【:】
        T_Pointer_Head = strstr(T_Pointer_Head, "\"") + 1;            // 【值的首指针】
        T_Pointer_end = strstr(T_Pointer_Head, "\"");                // 【"值"尾的"】
        T_Value_Len = T_Pointer_end - T_Pointer_Head;                    // 计算【值】的长度
        memcpy(A_JSONTree_Value, T_Pointer_Head, T_Value_Len);        // 获取【值】
        A_JSONTree_Value[T_Value_Len] = '\0';                            // 【值后添'\0'】
        os_printf("\t temp:%s\n",A_JSONTree_Value);


        //【注："humid"键所对应的值是数字。数字同样是由ASSIC码表示，但是没有""】
        T_Pointer_Head = strstr(T_Pointer_Head, "\"humid\"");        // 【"humid"】
        T_Pointer_Head = strstr(T_Pointer_Head, ":");                // 【:】

        // 获取数字的首指针【数字为十进制形式，并且没有""】
        //-----------------------------------------------------
     while(*T_Pointer_Head < '0' || *T_Pointer_Head > '9')    // 排除不在【0～9】范围内的字符
            T_Pointer_Head ++ ;

        T_Pointer_end = T_Pointer_Head; // 设置数字尾指针初值

        // 获取数字的尾指针+1【数字为十进制形式，并且没有""】
        //-----------------------------------------------------
        while(*T_Pointer_end >= '0' && *T_Pointer_end <= '9')    // 计算在【0～9】范围内的字符
            T_Pointer_end ++ ;

        T_Value_Len = T_Pointer_end - T_Pointer_Head+3;                    // 计算【值(数字)】的长度
        memcpy(A_JSONTree_Value, T_Pointer_Head, T_Value_Len);        // 获取【值(数字)】
        A_JSONTree_Value[T_Value_Len] = '\0';                            // 【值后添'\0'】
        os_printf("\t humid:%s\n",A_JSONTree_Value);

    //    T_Pointer_Head = strstr(T_Pointer_Head, "}");                // 【}】
    //    T_Pointer_Head = strstr(T_Pointer_Head, ",");                // 【,】
        //………………………………………………………………………………………………………………

        // 【"result"】
        //………………………………………………………………………………………………………………
        T_Pointer_Head = strstr(T_Pointer_Head, "\"result\"");        // 【"result"】
        T_Pointer_Head = strstr(T_Pointer_Head, ":");                // 【:】
        T_Pointer_Head = strstr(T_Pointer_Head, "\"") + 1;            // 【值的首指针】
        T_Pointer_end = strstr(T_Pointer_Head, "\"");                // 【"值"尾的"】
        T_Value_Len = T_Pointer_end - T_Pointer_Head;                    // 计算【值】的长度
        memcpy(A_JSONTree_Value, T_Pointer_Head, T_Value_Len);        // 获取【值】
        A_JSONTree_Value[T_Value_Len] = '\0';                            // 【值后添'\0'】
        os_printf("result:%s\n",A_JSONTree_Value);

        T_Pointer_Head = strstr(T_Pointer_Head, "}");            // 【}】
        //………………………………………………………………………………………………………………

        os_printf("\r\n---------------------------------------\r\n");

        return ;

}
/******************************************************************************
 * FunctionName : user_init
 * Description  : entry of user application, init user function here
 * Parameters   : none
 * Returns      : none
*******************************************************************************/
void vTaskMyJson( void *pvParameters )
{
    for(;;)
    {
        os_printf("JSON_Tree_Format:\n%s", JSON_Tree_Format);    // 打印JSON树格式

        Setup_JSON_Tree_JX();        // 创建JSON树

        Parse_JSON_Tree_JX();        // 解析JSON树

       // vTaskDelay(100);

        //vTaskDelete(NULL);

        return ;
    }
}

/******************************************************************************
 * FunctionName : user_init
 * Description  : entry of user application, init user function here
 * Parameters   : none
 * Returns      : none
*******************************************************************************/
void ICACHE_FLASH_ATTR user_init(void)
{
/********************************************
 * 函數PIN_FUNC_SELECT(PIN_NAME,FUNC)
 * PIN_NAME   管腳名字          PERIPHS_IO_MUX_ 加管腳名
 * FUNC       管腳功能          功能序號 - 1 （功能序號由ESP826管腳清單查找）
 * 函數GPIO_OUTPUT_SET(gpio_no,	bit_value)
 * gpio_no    IO口序號          GPIO_ID_PIN(IO口序號)
 * bit_value  1                      輸出高電平
 *            0                      輸出低電平
*********************************************/
	os_printf("\r\n===================================================\r\n");
	os_printf("\r\n esp8266 project \r\n");
	os_printf("\r\n IDE:AiThinker v1.5.2 \r\n");
	os_printf("\r\n SDK:nonos_sdk_v2.2 \r\n");
	os_printf("\r\n===================================================\r\n");

	vTaskMyJson(NULL);

}

