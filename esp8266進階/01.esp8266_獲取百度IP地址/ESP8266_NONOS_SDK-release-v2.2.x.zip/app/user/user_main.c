/*
 * ESPRESSIF MIT License
 *
 * Copyright (c) 2016 <ESPRESSIF SYSTEMS (SHANGHAI) PTE LTD>
 *
 * Permission is hereby granted for use on ESPRESSIF SYSTEMS ESP8266 only, in which case,
 * it is free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the Software is furnished
 * to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#include "ets_sys.h"
#include "osapi.h"
#include "user_interface.h"

#include "driver/uart.h"
#include "gpio.h"
#include "espconn.h"

//宏定義

#define  dns_ip "www.baidu.com"    //定義域名
//結構體
struct	espconn udp_config;
esp_udp udp_config_proto;
struct	espconn	tcp_config;
esp_tcp tcp_proto;
struct	softap_config ap_config;
struct	station_config	station_config;
ip_addr_t dns_config;

/******************************************************************************
 * FunctionName : user_rf_cal_sector_set
 * Description  : SDK just reversed 4 sectors, used for rf init data and paramters.
 *                We add this function to force users to set rf cal sector, since
 *                we don't know which sector is free in user's application.
 *                sector map for last several sectors : ABCCC
 *                A : rf cal
 *                B : rf init data
 *                C : sdk parameters
 * Parameters   : none
 * Returns      : rf cal sector
*******************************************************************************/
uint32 ICACHE_FLASH_ATTR
user_rf_cal_sector_set(void)
{
    enum flash_size_map size_map = system_get_flash_size_map();
    uint32 rf_cal_sec = 0;

    switch (size_map) {
        case FLASH_SIZE_4M_MAP_256_256:
            break;

        case FLASH_SIZE_8M_MAP_512_512:
            break;

        case FLASH_SIZE_16M_MAP_512_512:
            break;
        case FLASH_SIZE_16M_MAP_1024_1024:
            break;

        case FLASH_SIZE_32M_MAP_512_512:
            break;
        case FLASH_SIZE_32M_MAP_1024_1024:
            break;

        case FLASH_SIZE_64M_MAP_1024_1024:
            break;
        case FLASH_SIZE_128M_MAP_1024_1024:
            break;
        default:
            break;
    }

    return rf_cal_sec;
}
void ICACHE_FLASH_ATTR user_rf_pre_init(void)
{
}
/******************************************************************************
 * 設置ESP8266為station模式
*******************************************************************************/
//u8 station_ssid[32] = "iPhone1";
//u8 station_password[32] = "12345678";
#define esp8266_station_ssid "iPhone1"
#define esp8266_station_password "12345678"
void esp8266_station_config(void)
{
	wifi_set_opmode(0x01);                  //設置為station模式
	station_config.bssid_set = 0;
	os_strcpy(station_config.ssid,esp8266_station_ssid);
	os_strcpy(station_config.password,esp8266_station_password);
	//os_memcpy(station_config.ssid,station_ssid,32);
	//os_memcpy(station_config.password,station_password,32);
	wifi_station_set_config	(&station_config);
}
/******************************************************************************
 * 設置ESP8266為AP模式
*******************************************************************************/
#define ap_config_ssid      "esp8266_softap"
#define ap_config_password  "12345678"

void esp8266_ap_config(void)
{
	wifi_set_opmode (0x02);                                  //設置模式為ap模式
	os_memset(&ap_config,0,sizeof(struct softap_config));    //將ap參數結構體清0
	os_strcpy(ap_config.ssid,ap_config_ssid);                //設置wifi名稱
	os_strcpy(ap_config.password,ap_config_password);        //設置wifi密碼
	ap_config.authmode = AUTH_WPA2_PSK;
	ap_config.beacon_interval = 100;
	ap_config.channel =1;
	ap_config.max_connection = 2;
	ap_config.ssid_hidden = 0;
	ap_config.ssid_len = os_strlen(ap_config_ssid);
	wifi_softap_set_config(&ap_config);
}
/******************************************************************************
 * 設置ESP8266通信接收回調函數
*******************************************************************************/
void esp8266_recv_callback(void *arg,char *pdata,unsigned short	len)
{
	os_printf("Receive data:%s\r\n",pdata);
	espconn_send(arg,"Receive data",os_strlen("receive data"));
}
/******************************************************************************
 * 設置ESP8266通信發送回調函數
*******************************************************************************/
void esp8266_sent_callback(void *arg)
{
	//espconn_send(arg,"Sent data",os_strlen("Sent data"));
}
/******************************************************************************
 * 設置ESP8266_TCP通信
*******************************************************************************/
//連接成功回調函數
void esp8266_connect_callback(void *arg)
{
	os_printf("\r\n===============TCP Connect================\r\n");
	espconn_regist_recvcb(&tcp_config,esp8266_recv_callback);    //註冊接收回調函數
	espconn_regist_sentcb (&tcp_config,esp8266_sent_callback);    //註冊發送回調函數
}
//斷開連接回調函數
void esp8266_discon_callback(void *arg)
{
	os_printf("\r\n==============TCP Disconnect==============\r\n");
}
//dns域名解析回調函數
void dns_ipget_callback(const char *name,ip_addr_t *ipaddr,void	*arg)
{
		struct	espconn	*pespconn	=	(struct	espconn	*)arg;
		if(ipaddr == NULL)
		{
			os_printf("\r\n==================DNS IP GET ERROR==================\r\n");
		}
		else if	(ipaddr	!=	NULL)
	 	 {
				os_printf("\r\n==================DNS IP GET==================\r\n");
				os_printf("	DNS IP:%d.%d.%d.%d\n",
				*((uint8	*)&ipaddr->addr),   *((uint8	*)&ipaddr->addr	+	1),
				*((uint8	*)&ipaddr->addr	+2),*((uint8	*)&ipaddr->addr	+	3));

	 	 }
}
//tcp協議初始化
void esp8266_tcp_config(void)
{
	tcp_config.type = ESPCONN_TCP ;  //設置為TCP模式
	tcp_config.proto.tcp = &tcp_proto;
	tcp_config.proto.tcp->local_port = 8266;  //本機端口
	//設置遠端信息
	tcp_config.proto.tcp->remote_port = 80;  //遠端端口
	//開啟dns
	espconn_gethostbyname(&tcp_config,dns_ip,&dns_config,dns_ipget_callback);
	//設置回調函數
	espconn_regist_connectcb(&tcp_config,esp8266_connect_callback);
	espconn_regist_disconcb(&tcp_config,esp8266_discon_callback);
	//espconn_connect(&tcp_config);
}
/******************************************************************************
 * ms延時函數
*******************************************************************************/

void ICACHE_FLASH_ATTR delay_ms(u32 C_time)
{
	for(;C_time>0;C_time--)
	{
		os_delay_us(1000);
	}

}
/******************************************************************************
 * os_time軟件定時器
*******************************************************************************/
//中斷函數
os_timer_t	os_timer_config;
void os_time_interrupt(void)
{
	switch(wifi_station_get_connect_status ())
	{
	case 0: os_printf("\r\n=======================STATION_IDLE======================\r\n");
		break;
	case 1: os_printf("\r\n===================== STATION_CONNECTING==================\r\n");
		break;
	case 2: os_printf("\r\n===================STATION_WRONG_PASSWORD=================\r\n");
		break;
	case 3: os_printf("\r\n=====================STATION_NO_AP_FOUND==================\r\n");
		break;
	case 4: os_printf("\r\n====================STATION_CONNECT_FAIL==================\r\n");
		break;
	case 5: os_printf("\r\n=======================STATION_GOT_IP=====================\r\n");  //連接成功
			esp8266_tcp_config();               //tcp dns 初始化
			os_timer_disarm(&os_timer_config);  //已經連接wifi關閉定時器,準備獲取域名IP地址
		break;
	}
}
//初始化
void os_time_config(uint32_t time,u8 repeat_flag)
{
	os_timer_disarm	(&os_timer_config);  //取消軟件定時器
	os_timer_setfn(&os_timer_config,(os_timer_func_t *)os_time_interrupt,NULL);
	os_timer_arm(&os_timer_config,time,repeat_flag);  //初始化  time 定時時間 ms， repeat——flag 0不重複 1重複

}
/******************************************************************************
 * FunctionName : user_init
 * Description  : entry of user application, init user function here
 * Parameters   : none
 * Returns      : none
*******************************************************************************/
void ICACHE_FLASH_ATTR user_init(void)
{
	/********************************************
	* 函數PIN_FUNC_SELECT(PIN_NAME,FUNC)
	* PIN_NAME   管腳名字          PERIPHS_IO_MUX_ 加管腳名
	* FUNC       管腳功能          功能序號 - 1 （功能序號由ESP826管腳清單查找）
	* 函數GPIO_OUTPUT_SET(gpio_no,	bit_value)
	* gpio_no    IO口序號          GPIO_ID_PIN(IO口序號)
	* bit_value  1                      輸出高電平
	*            0                      輸出低電平
	*********************************************/
	os_printf("\r\n===================================================\r\n");
	os_printf("\r\n esp8266 project \r\n");
	os_printf("\r\n IDE:AiThinker v1.5.2 \r\n");
	os_printf("\r\n SDK:nonos_sdk_v2.2 \r\n");
	os_printf("\r\n===================================================\r\n");
	esp8266_station_config();

	os_time_config(500,1);

    switch(wifi_get_opmode())
    {
    case 0x01 : os_printf("\r\n================== Station Mode================== \r\n");
    break;
    case 0x02 : os_printf("\r\n================== SoftAP Mode================== \r\n");
    break;
    case 0x03 : os_printf("\r\n ==================Station+SoftAP Mode================== \r\n");
    break;
    }

}

